# smart-waste-sorting-app
MAUI app that uses Azure Custom Vision AI and connects to ASP.NET API


## How to run this app?
1. Make sure the custom vision credentials are right
2. Install dotnet 8
3. Run the ASP.NET API -> "SmartWasteSortingApi"
4. Run the MAUI APP -> "SmartWasteSortingApp" (both Windows and Android emulator work)

## This version only works locally
Since the api url is hardcoded with localhost

## TODO
Taartgrafiek
Zakken leegmaken
Custom Vision op meer producten trainen zodat app meer afval naar de juiste zak kan sturen