using SmartWasteSortingApp.ViewModels;

namespace SmartWasteSortingApp.Views;

public partial class WasteClassificationPage : ContentPage
{
	public WasteClassificationPage(IWasteClassificationViewModel viewModel)
	{
		InitializeComponent();

		BindingContext = viewModel;
	}
}