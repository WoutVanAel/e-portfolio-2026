using SmartWasteSortingApp.ViewModels;

namespace SmartWasteSortingApp.Views;

public partial class MyBagsPage : ContentPage
{
	public MyBagsPage(IMyBagsViewModel viewModel)
	{
		InitializeComponent();

		BindingContext = viewModel;
	}
}