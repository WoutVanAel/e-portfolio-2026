using SmartWasteSortingApp.ViewModels;

namespace SmartWasteSortingApp.Views;

public partial class SortPage : ContentPage
{
	public SortPage(ISortViewModel viewModel)
	{
		InitializeComponent();

		BindingContext = viewModel;
	}
}