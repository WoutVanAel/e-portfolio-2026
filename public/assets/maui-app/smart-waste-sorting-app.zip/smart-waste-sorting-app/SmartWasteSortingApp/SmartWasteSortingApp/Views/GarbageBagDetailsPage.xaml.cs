using SmartWasteSortingApp.ViewModels;

namespace SmartWasteSortingApp.Views;

public partial class GarbageBagDetailsPage : ContentPage
{
	public GarbageBagDetailsPage(IGarbageBagDetailsViewModel viewModel)
	{
		InitializeComponent();

		BindingContext = viewModel;
	}
}