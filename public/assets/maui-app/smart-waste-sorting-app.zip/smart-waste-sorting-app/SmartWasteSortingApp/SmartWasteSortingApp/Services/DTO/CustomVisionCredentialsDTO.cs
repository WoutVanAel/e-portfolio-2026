﻿namespace SmartWasteSortingApp.Services.DTO
{
    public class CustomVisionCredentialsDTO
    {
        public string CustomVisionEndPoint { get; set; }
        public string PredictionKey { get; set; }
        public string ProjectId { get; set; }
        public string PublishedName { get; set; }
    }
}
