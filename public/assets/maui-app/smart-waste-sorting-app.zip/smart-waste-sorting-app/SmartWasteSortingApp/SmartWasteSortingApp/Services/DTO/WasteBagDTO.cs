﻿namespace SmartWasteSortingApp.Services.DTO
{
    public class WasteBagDTO
    {
        public int Id { get; set; }
        public string BagType { get; set; }
        public IList<WasteItemDTO> WasteItems { get; set; }
    }
}
