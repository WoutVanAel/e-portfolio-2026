﻿using SmartWasteSortingApp.Services.DTO;

namespace SmartWasteSortingApp.Services
{
    public interface IApiService
    {
        Task<WasteBagDTO> GetBagAndIncreaseItemCountByPredictionTag(string tagName);

        Task<List<string>> GetAllTypesOfBags();
        
        Task<List<WasteItemDTO>> GetAllItemsInABag(string wasteBagType);
    }
}
