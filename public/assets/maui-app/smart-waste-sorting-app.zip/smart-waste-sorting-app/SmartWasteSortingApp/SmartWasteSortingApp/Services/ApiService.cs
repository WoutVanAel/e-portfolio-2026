﻿using System;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using SmartWasteSortingApp.Services.DTO;

namespace SmartWasteSortingApp.Services
{
    public class ApiService : IApiService
    {
        private readonly JsonSerializerSettings _serializerSettings;
#if ANDROID
        private readonly string apiUrl = "http://10.0.2.2:5087";
#else
        private readonly string apiUrl = "http://localhost:5087";
#endif

        public ApiService()
        {
            _serializerSettings = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                DateTimeZoneHandling = DateTimeZoneHandling.Utc,
                NullValueHandling = NullValueHandling.Ignore
            };
            _serializerSettings.Converters.Add(new StringEnumConverter());
        }

        public async Task<WasteBagDTO> GetBagAndIncreaseItemCountByPredictionTag(string tagName)
        {
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await httpClient.GetAsync($"{apiUrl}/api/waste/increase-item-count/{tagName}");

            string serialized = await response.Content.ReadAsStringAsync();

            WasteBagDTO result = await Task.Run(() => JsonConvert.DeserializeObject<WasteBagDTO>(serialized, _serializerSettings));

            return result;
        }

        public async Task<List<string>> GetAllTypesOfBags()
        {
            
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await httpClient.GetAsync($"{apiUrl}/api/waste/types-of-bags");

            string serialized = await response.Content.ReadAsStringAsync();

            var result = await Task.Run(() => JsonConvert.DeserializeObject<List<string>>(serialized, _serializerSettings));

            return result;
        }

        public async Task<List<WasteItemDTO>> GetAllItemsInABag(string wasteBagType)
        {
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await httpClient.GetAsync($"{apiUrl}/api/waste/bag-items/{wasteBagType}");

            string serialized = await response.Content.ReadAsStringAsync();

            var result = await Task.Run(() => JsonConvert.DeserializeObject<List<WasteItemDTO>>(serialized, _serializerSettings));

            return result;
        }
    }
}
