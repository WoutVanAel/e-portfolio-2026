﻿namespace SmartWasteSortingApp.Services
{
    public interface INavigationService
    {
        Task NavigateToWasteClassificationPageAsync();
        Task NavigateToGarbageBagDetailsPageAsync();
        Task NavigateBackAsync();
    }
}
