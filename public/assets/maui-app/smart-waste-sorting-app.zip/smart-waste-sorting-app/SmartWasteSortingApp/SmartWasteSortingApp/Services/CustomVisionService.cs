﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.Azure.CognitiveServices.Vision.CustomVision.Prediction;
using SmartWasteSortingApp.Models;
using SmartWasteSortingApp.Services.DTO;

namespace SmartWasteSortingApp.Services
{
    public static class ApiKeys
    {
        // This class is not used at the moment
        public static async Task<string> GetCustomVisionEndPointAsync()
        {
            return await SecureStorage.GetAsync("CustomVisionEndPoint") ?? string.Empty;
        }

        public static async Task<string> GetPredictionKeyAsync()
        {
            return await SecureStorage.GetAsync("PredictionKey") ?? string.Empty;
        }

        public static async Task<string> GetProjectIdAsync()
        {
            return await SecureStorage.GetAsync("ProjectId") ?? string.Empty;
        }

        public static async Task<string> GetPublishedNameAsync()
        {
            return await SecureStorage.GetAsync("PublishedName") ?? string.Empty;
        }
    }

    public class CustomVisionService
    {
#if ANDROID
        private static readonly string apiUrl = "http://10.0.2.2:5087";
#else
        private static readonly string apiUrl = "http://localhost:5087";
#endif

        public static async Task<List<WasteCustomVisionPredictionModel>> ClassifyImageAsync(Stream photoStream)
        {
            try
            {
                // Fetch custom vision credentials from api
                var httpClient = new HttpClient();
                var credentials = await httpClient.GetFromJsonAsync<CustomVisionCredentialsDTO>($"{apiUrl}/api/keys");

                var endpoint = new CustomVisionPredictionClient(new ApiKeyServiceClientCredentials(credentials.PredictionKey))
                {
                    Endpoint = credentials.CustomVisionEndPoint,
                };

                // Send image to the Custom Vision API
                var results = await endpoint.ClassifyImageAsync(Guid.Parse(credentials.ProjectId), credentials.PublishedName, photoStream);

                // Return prediction sorted by most likely first and mapped to the WasteCustomVisionPredictionModel
                return results.Predictions
                    .OrderByDescending(x => x.Probability)
                    .Select(prediction => new WasteCustomVisionPredictionModel
                    {
                        TagName = prediction.TagName,
                        Probability = prediction.Probability
                    })
                    .ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return [];
            }
        }
    }
}
