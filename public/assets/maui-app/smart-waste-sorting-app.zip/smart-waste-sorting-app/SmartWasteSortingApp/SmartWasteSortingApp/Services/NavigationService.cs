﻿
using SmartWasteSortingApp.Views;

namespace SmartWasteSortingApp.Services
{
    public class NavigationService : INavigationService
    {
        private INavigation _navigation;
        private IServiceProvider _serviceProvider;

        public NavigationService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _navigation = Application.Current.MainPage.Navigation;
        }

        public async Task NavigateToWasteClassificationPageAsync()
        {
            await _navigation.PushAsync(_serviceProvider.GetRequiredService<WasteClassificationPage>());
        }

        public async Task NavigateToGarbageBagDetailsPageAsync()
        {
            await _navigation.PushAsync(_serviceProvider.GetRequiredService<GarbageBagDetailsPage>());
        }

        public async Task NavigateBackAsync()
        {
            if (_navigation.NavigationStack.Count > 1)
            {
                await _navigation.PopAsync();
            }
            else
            {
                throw new InvalidOperationException("No pages to navigate back to!");
            }
        }
    }
}
