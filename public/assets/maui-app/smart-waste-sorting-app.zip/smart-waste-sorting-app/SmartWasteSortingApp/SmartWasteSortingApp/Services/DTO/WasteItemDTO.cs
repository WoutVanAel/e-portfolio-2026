﻿namespace SmartWasteSortingApp.Services.DTO
{
    public class WasteItemDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Count { get; set; }
        public int WasteBagId { get; set; }
    }
}
