﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SmartWasteSortingApp.Models
{
    public class GarbageBinModel : ObservableObject
    {
        private string _name = string.Empty;
        public string Name
        {
            get => _name;
            set
            {
                SetProperty(ref _name, value);
                // Automatically update the Photo when Name changes
                Photo = GetImageForGarbageBin(value);
            }
        }

        private string _message = string.Empty;
        public string Message
        {
            get => _message;
            set => SetProperty(ref _message, value);
        }

        private ImageSource _photo = ImageSource.FromFile("");
        public ImageSource Photo
        {
            get => _photo;
            set => SetProperty(ref _photo, value);
        }

        // Logic to assign the corresponding photo based on the name
        private static ImageSource GetImageForGarbageBin(string binName)
        {
            var imageName = $"{binName.ToLower()}.png";

            return ImageSource.FromFile(imageName);
        }

    }
}
