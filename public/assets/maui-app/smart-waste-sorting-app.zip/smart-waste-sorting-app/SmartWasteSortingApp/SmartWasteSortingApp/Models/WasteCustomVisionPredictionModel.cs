﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SmartWasteSortingApp.Models
{
    public class WasteCustomVisionPredictionModel : ObservableObject
    {
        private string _tagName = string.Empty;
        public string TagName { 
            get => _tagName;
            set
            {
                SetProperty(ref _tagName, value);
                OnPropertyChanged(nameof(DisplayText));
            }
        }

        private double _probability = 0;
        public double Probability {
            get => _probability; 
            set
            {
                SetProperty(ref _probability, value);
                OnPropertyChanged(nameof(DisplayText));
            }
        }

        public string DisplayText
        {
            get => $"{TagName} - {Probability.ToString("P1")}";
        }
    }
}
