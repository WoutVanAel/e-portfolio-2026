﻿using Microsoft.Extensions.Logging;
using SmartWasteSortingApp.Services;
using SmartWasteSortingApp.ViewModels;
using SmartWasteSortingApp.Views;

namespace SmartWasteSortingApp
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

#if DEBUG
    		builder.Logging.AddDebug();
#endif

            // Services
            builder.Services.AddTransient<INavigationService, NavigationService>();
            builder.Services.AddTransient<IApiService, ApiService>();

            builder.Services.AddTransient<SortPage>();
            builder.Services.AddTransient<ISortViewModel, SortViewModel>();

            builder.Services.AddTransient<WasteClassificationPage>();
            builder.Services.AddTransient<IWasteClassificationViewModel, WasteClassificationViewModel>();

            builder.Services.AddTransient<MyBagsPage>();
            builder.Services.AddTransient<IMyBagsViewModel, MyBagsViewModel>();

            builder.Services.AddTransient<GarbageBagDetailsPage>();
            builder.Services.AddTransient<IGarbageBagDetailsViewModel, GarbageBagDetailsViewModel>();

            return builder.Build();
        }
    }
}
