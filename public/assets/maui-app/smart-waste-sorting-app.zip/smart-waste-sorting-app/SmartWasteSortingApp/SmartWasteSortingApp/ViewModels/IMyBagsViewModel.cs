﻿using System.Collections.ObjectModel;
using System.Windows.Input;

namespace SmartWasteSortingApp.ViewModels
{
    public interface IMyBagsViewModel
    {
        ICommand BagTappedCommand { get; set; }
        ObservableCollection<string> BagTypes { get; }
        bool IsRunning { get; set; }
    }
}
