﻿using System.Collections.ObjectModel;
using SmartWasteSortingApp.Services.DTO;

namespace SmartWasteSortingApp.ViewModels
{
    public interface IGarbageBagDetailsViewModel
    {
        string WasteBagType { get; set; }
        ObservableCollection<WasteItemDTO> Items { get; set; }
        bool IsRunning { get; set; }
    }
}
