﻿using System.Windows.Input;
using SmartWasteSortingApp.Models;

namespace SmartWasteSortingApp.ViewModels
{
    public interface ISortViewModel
    {
        ICommand TakePhotoCommand { get; set; }

        GarbageBinModel GarbageBin { get; set; }

        bool IsRunning { get; set; }
    }
}
