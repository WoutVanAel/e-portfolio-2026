﻿using System.Windows.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using SmartWasteSortingApp.Messages;
using SmartWasteSortingApp.Models;
using SmartWasteSortingApp.Services;

namespace SmartWasteSortingApp.ViewModels
{
    public class WasteClassificationViewModel : ObservableRecipient, IWasteClassificationViewModel, IRecipient<WastePhotoTakenMessage>
    {
        public async void Receive(WastePhotoTakenMessage message)
        {
            if (message.Value is { })
            {
                IsRunning = true;

                // Resize to allowed size - 4MB
                var resizedPhoto = await PhotoImageService.ResizePhotoStreamAsync(message.Value);
                WastePhoto = ImageSource.FromStream(() => new MemoryStream(resizedPhoto));

                // Custom Vision API call
                var result = await CustomVisionService.ClassifyImageAsync(new MemoryStream(resizedPhoto));

                // Set the picker if not empty
                if (result != null && result.Count != 0)
                {
                    CustomVisionPredictions = result;
                    SelectedPrediction = result.First();
                }

                IsRunning = false;
            }
        }

        private bool _isRunning = false;

        public bool IsRunning
        {
            get => _isRunning;
            set => SetProperty(ref _isRunning, value);
        }

        private ImageSource _wastePhoto = ImageSource.FromFile("");

        public ImageSource WastePhoto
        {
            get => _wastePhoto;
            set => SetProperty(ref _wastePhoto, value);
        }

        private List<WasteCustomVisionPredictionModel> _customVisionPredictions = [];
        public List<WasteCustomVisionPredictionModel> CustomVisionPredictions
        {
            get => _customVisionPredictions;
            set => SetProperty(ref _customVisionPredictions, value);
        }

        private WasteCustomVisionPredictionModel _selectedPrediction = new();
        public WasteCustomVisionPredictionModel SelectedPrediction
        {
            get => _selectedPrediction;
            set => SetProperty(ref _selectedPrediction, value);
        }

        public ICommand AddToBagCommand {  get; set; }

        private INavigationService _navigationService;
        private IApiService _apiService;

        public WasteClassificationViewModel(INavigationService navigationService, IApiService apiService)
        {
            _navigationService = navigationService;
            _apiService = apiService;

            Messenger.Register<WasteClassificationViewModel, WastePhotoTakenMessage>(this, (r, m) => r.Receive(m));

            AddToBagCommand = new AsyncRelayCommand(AddToBagAndGoBack);
        }

        private async Task AddToBagAndGoBack()
        {
            // Send request to api with waste item so it can be added to a bag
            var result = await _apiService.GetBagAndIncreaseItemCountByPredictionTag(SelectedPrediction.TagName);

            // Send waste bag to SortViewModel so it can be displayed with the correct trash can
            WeakReferenceMessenger.Default.Send(new GarbageBinForPredictionMessage(result.BagType));

            await _navigationService.NavigateBackAsync();
        }

    }
}
