﻿using System.Windows.Input;
using SmartWasteSortingApp.Models;

namespace SmartWasteSortingApp.ViewModels
{
    public interface IWasteClassificationViewModel
    {
        ICommand AddToBagCommand { get; set; }

        ImageSource WastePhoto {  get; set; }

        List<WasteCustomVisionPredictionModel> CustomVisionPredictions { get; set; }
        WasteCustomVisionPredictionModel SelectedPrediction { get; set; }

        bool IsRunning { get; set; }
    }
}
