﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using SmartWasteSortingApp.Messages;
using SmartWasteSortingApp.Services;

namespace SmartWasteSortingApp.ViewModels
{
    public class MyBagsViewModel : ObservableObject, IMyBagsViewModel
    {
        private bool _isRunning = false;

        public bool IsRunning
        {
            get => _isRunning;
            set => SetProperty(ref _isRunning, value);
        }

        private ObservableCollection<string> _bagTypes = [];
        public ObservableCollection<string> BagTypes { 
            get => _bagTypes; 
            set => SetProperty(ref _bagTypes, value); 
        }

        public ICommand BagTappedCommand { get; set; }

        private IApiService _apiService;
        private INavigationService _navigationService;
        
        public MyBagsViewModel(IApiService apiService, INavigationService navigationService)
        {
            _apiService = apiService;
            _navigationService = navigationService;

            BagTappedCommand = new AsyncRelayCommand<string>(GoToBagDetailsAsync);

            // Load bag types on initialization
            LoadBagTypes();
        }

        private async void LoadBagTypes()
        {
            try
            {
                BagTypes = new ObservableCollection<string>(await _apiService.GetAllTypesOfBags());
            }
            catch (Exception ex)
            {
                // Handle exceptions (log or show an alert)
                Console.WriteLine($"Failed to load bag types: {ex.Message}");
            }
        }

        private async Task GoToBagDetailsAsync(string? bagType)
        {
            if (bagType != null)
            {
                WeakReferenceMessenger.Default.Send(new GarbageBagInDetailMessage(bagType));
                await _navigationService.NavigateToGarbageBagDetailsPageAsync();
            }
        }
    }
}
