﻿using System.Windows.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using SmartWasteSortingApp.Messages;
using SmartWasteSortingApp.Models;
using SmartWasteSortingApp.Services;

namespace SmartWasteSortingApp.ViewModels
{
    public class SortViewModel : ObservableRecipient, ISortViewModel, IRecipient<GarbageBinForPredictionMessage>
    {
        public void Receive(GarbageBinForPredictionMessage message)
        {
            if (message.Value is { })
            {
                IsRunning = true;

                // Set the garbage bin that the api returned as name to display
                GarbageBin.Name = message.Value;

                // Also set the message
                GarbageBin.Message = $"Gooi dit afval in de {message.Value} zak.";

                IsRunning = false;
            }
        }

        private bool _isRunning = false;

        public bool IsRunning
        {
            get => _isRunning;
            set => SetProperty(ref _isRunning, value);
        }

        private GarbageBinModel _garbageBin = new GarbageBinModel();
        public GarbageBinModel GarbageBin
        {
            get => _garbageBin;
            set => SetProperty(ref _garbageBin, value);
        }

        public ICommand TakePhotoCommand { get; set; }

        private INavigationService _navigationService;
        
        public SortViewModel(INavigationService navigationService)
        {
            _navigationService = navigationService;

            Messenger.Register<SortViewModel, GarbageBinForPredictionMessage>(this, (r, m) => r.Receive(m));

            TakePhotoCommand = new AsyncRelayCommand(TakeAndClassifyPhotoAsync);
        }

        private async Task TakeAndClassifyPhotoAsync()
        {
            var photo = await MediaPicker.Default.CapturePhotoAsync();
            if (photo is { })
            {
                await _navigationService.NavigateToWasteClassificationPageAsync();
                WeakReferenceMessenger.Default.Send(new WastePhotoTakenMessage(photo));
            }
        }
    }
}
