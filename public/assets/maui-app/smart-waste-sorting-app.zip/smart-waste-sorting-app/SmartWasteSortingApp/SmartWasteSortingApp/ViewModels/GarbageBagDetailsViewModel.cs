﻿using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Messaging;
using SmartWasteSortingApp.Messages;
using SmartWasteSortingApp.Services;
using SmartWasteSortingApp.Services.DTO;

namespace SmartWasteSortingApp.ViewModels
{
    public class GarbageBagDetailsViewModel : ObservableRecipient, IGarbageBagDetailsViewModel, IRecipient<GarbageBagInDetailMessage>
    {
        public void Receive(GarbageBagInDetailMessage message)
        {
            if (message.Value != null)
            {
                IsRunning = true;

                WasteBagType = message.Value;

                LoadWasteItems();

                IsRunning = false;
            }
        }

        private bool _isRunning = false;

        public bool IsRunning
        {
            get => _isRunning;
            set => SetProperty(ref _isRunning, value);
        }

        private string _wasteBagType = string.Empty;
        public string WasteBagType
        {
            get => _wasteBagType;
            set => SetProperty(ref _wasteBagType, value);
        }

        private ObservableCollection<WasteItemDTO> _items = [];
        public ObservableCollection<WasteItemDTO> Items
        {
            get => _items;
            set => SetProperty(ref _items, value);
        }

        private IApiService _apiService;

        public GarbageBagDetailsViewModel(IApiService apiService)
        {
            _apiService = apiService;

            Messenger.Register<GarbageBagDetailsViewModel, GarbageBagInDetailMessage>(this, (r, m) => r.Receive(m));
        }

        private async void LoadWasteItems()
        {
            try
            {
                Items = new ObservableCollection<WasteItemDTO>(await _apiService.GetAllItemsInABag(WasteBagType));
            }
            catch (Exception ex)
            {
                // Handle exceptions (log or show an alert)
                Console.WriteLine($"Failed to load waste items: {ex.Message}");
            }
        }
    }
}
