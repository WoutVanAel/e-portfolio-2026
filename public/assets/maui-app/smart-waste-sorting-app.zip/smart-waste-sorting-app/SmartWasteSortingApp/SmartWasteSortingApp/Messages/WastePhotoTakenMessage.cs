﻿using CommunityToolkit.Mvvm.Messaging.Messages;

namespace SmartWasteSortingApp.Messages
{
    public class WastePhotoTakenMessage(FileResult photo) : ValueChangedMessage<FileResult>(photo)
    {
    }
}
