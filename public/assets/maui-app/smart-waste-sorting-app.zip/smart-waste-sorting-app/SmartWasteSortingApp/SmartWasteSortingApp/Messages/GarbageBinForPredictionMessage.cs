﻿using CommunityToolkit.Mvvm.Messaging.Messages;

namespace SmartWasteSortingApp.Messages
{
    public class GarbageBinForPredictionMessage(string binName) : ValueChangedMessage<string>(binName)
    {
    }
}
