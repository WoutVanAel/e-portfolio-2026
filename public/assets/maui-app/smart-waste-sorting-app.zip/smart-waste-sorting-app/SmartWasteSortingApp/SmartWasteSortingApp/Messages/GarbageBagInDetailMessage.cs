﻿using CommunityToolkit.Mvvm.Messaging.Messages;

namespace SmartWasteSortingApp.Messages
{
    public class GarbageBagInDetailMessage(string binType) : ValueChangedMessage<string>(binType)
    {
    }
}
