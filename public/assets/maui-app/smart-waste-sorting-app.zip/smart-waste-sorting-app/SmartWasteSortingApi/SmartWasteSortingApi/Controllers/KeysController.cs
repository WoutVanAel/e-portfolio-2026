﻿using Microsoft.AspNetCore.Mvc;
using SmartWasteSortingApi.Controllers.DTO;

namespace SmartWasteSortingApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KeysController : ControllerBase
    {
        // GET api/keys
        // Retrieves keys from env files so the client can use them
        [HttpGet]
        public IActionResult GetCustomVisionKeys()
        {
            // Load .env file
            DotNetEnv.Env.Load();

            // Copy the values to the DTO
            var credentials = new CustomVisionCredentialsDTO() { 
                CustomVisionEndPoint = DotNetEnv.Env.GetString("CUSTOM_VISION_ENDPOINT"),
                PredictionKey = DotNetEnv.Env.GetString("PREDICTION_KEY"),
                ProjectId = DotNetEnv.Env.GetString("PROJECT_ID"),
                PublishedName = DotNetEnv.Env.GetString("PUBLISHED_NAME")
            };

            // Return the credentials as a JSON response
            return Ok(credentials);
        }
    }
}
