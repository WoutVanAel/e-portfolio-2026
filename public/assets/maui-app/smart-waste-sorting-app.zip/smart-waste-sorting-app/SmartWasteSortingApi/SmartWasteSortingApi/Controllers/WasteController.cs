﻿using Microsoft.AspNetCore.Mvc;
using SmartWasteSortingApi.Data;

namespace SmartWasteSortingApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WasteController(IWasteRepository wasteRepository) : ControllerBase
    {
        private readonly IWasteRepository _wasteRepository = wasteRepository;

        // GET api/waste/increase-item-count/{wasteItemName}
        // Retrieves the waste bag for a specific item and increases the item's count
        [HttpGet("increase-item-count/{wasteItemName}")]
        public async Task<IActionResult> GetBagAndIncreaseItemCount(string wasteItemName)
        {
            // Retrieve the bag associated with the waste item
            var wasteBag = await _wasteRepository.GetBagByItemNameAsync(wasteItemName);

            // Check if the bag was found
            if (wasteBag == null)
            {
                return NotFound($"Waste item '{wasteItemName}' not found.");
            }

            // Increase the item count
            await _wasteRepository.IncreaseWasteItemCountByItemNameAsync(wasteItemName);

            // Retrieve the updated waste bag with the incremented count
            wasteBag = await _wasteRepository.GetBagByItemNameAsync(wasteItemName);

            // Return the updated bag details
            return Ok(wasteBag);
        }

        // GET api/waste/types-of-bags
        // Retrieves all the different types of bags you have
        [HttpGet("types-of-bags")]
        public async Task<IActionResult> GetAllTypesOfBags()
        {
            var wasteBags = await _wasteRepository.GetAllBagsAsync();

            var bagTypes = wasteBags
                .Select(b => b.BagType)
                .Distinct()
                .ToList();

            return Ok(bagTypes);
        }

        // GET api/waste/bag-items/{wasteBagType}
        // Retrieves all the waste that is in a bag with the amount
        [HttpGet("bag-items/{wasteBagType}")]
        public async Task<IActionResult> GetAllItemsInABag(string wasteBagType)
        {
            var wasteBag = await _wasteRepository.GetBagByTypeAsync(wasteBagType);

            if (wasteBag == null)
            {
                return NotFound($"Waste bag of type '{wasteBagType}' not found.");
            }

            var items = wasteBag.WasteItems
                .Where(item => item.Count > 0)
                .Select(item => new
                {
                    item.Id,
                    item.Name,
                    item.Count
                })
                .ToList();

            return Ok(items);
        }
    }
}
