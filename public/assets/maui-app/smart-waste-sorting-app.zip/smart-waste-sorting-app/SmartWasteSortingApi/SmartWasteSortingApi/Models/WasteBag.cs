﻿namespace SmartWasteSortingApi.Models
{
    public class WasteBag
    {
        public int Id { get; set; }
        public string BagType { get; set; }
        public ICollection<WasteItem>? WasteItems { get; set; }
    }
}
