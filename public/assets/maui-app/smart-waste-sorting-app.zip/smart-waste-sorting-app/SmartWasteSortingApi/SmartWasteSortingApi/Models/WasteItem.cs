﻿namespace SmartWasteSortingApi.Models
{
    public class WasteItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Count { get; set; } = 0;
        public int WasteBagId { get; set; }
        public WasteBag? WasteBag { get; set; }
    }
}
