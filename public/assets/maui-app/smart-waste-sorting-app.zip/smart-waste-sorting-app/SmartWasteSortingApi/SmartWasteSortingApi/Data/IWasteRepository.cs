﻿using SmartWasteSortingApi.Models;

namespace SmartWasteSortingApi.Data
{
    public interface IWasteRepository
    {
        Task<IList<WasteBag>> GetAllBagsAsync();
        Task<WasteBag> GetBagByTypeAsync(string wasteBagType);
        Task<WasteBag> GetBagByItemNameAsync(string wasteItemName);
        Task IncreaseWasteItemCountByItemNameAsync(string wasteItemName);
        Task EmptyWasteBagByIdAsync(int bagId);
    }
}
