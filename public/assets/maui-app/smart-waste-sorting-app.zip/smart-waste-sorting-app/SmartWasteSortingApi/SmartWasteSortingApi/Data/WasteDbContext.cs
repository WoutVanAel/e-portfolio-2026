﻿using Microsoft.EntityFrameworkCore;
using SmartWasteSortingApi.Models;

namespace SmartWasteSortingApi.Data
{
    public class WasteDbContext : DbContext
    {
        public WasteDbContext(DbContextOptions<WasteDbContext> options) : base(options) { }

        public DbSet<WasteBag> WasteBags { get; set; }
        public DbSet<WasteItem> WasteItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<WasteBag>().ToTable("WasteBag");
            modelBuilder.Entity<WasteItem>().ToTable("WasteItem");

            modelBuilder.Entity<WasteBag>()
                .HasMany(b => b.WasteItems)
                .WithOne(i => i.WasteBag)
                .HasForeignKey(i => i.WasteBagId);
        }
    }
}
