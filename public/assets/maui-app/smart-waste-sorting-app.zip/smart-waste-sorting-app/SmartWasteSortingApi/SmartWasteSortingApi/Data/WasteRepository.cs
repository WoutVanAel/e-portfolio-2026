﻿using Microsoft.EntityFrameworkCore;
using SmartWasteSortingApi.Models;

namespace SmartWasteSortingApi.Data
{
    public class WasteRepository(WasteDbContext context) : IWasteRepository
    {
        private readonly WasteDbContext _context = context;

        public async Task<IList<WasteBag>> GetAllBagsAsync()
        {
            return await _context.WasteBags.Include(b => b.WasteItems).ToListAsync();
        }

        public async Task<WasteBag> GetBagByTypeAsync(string wasteBagType)
        {
            return await _context.WasteBags.Include(b => b.WasteItems).FirstOrDefaultAsync(b => b.BagType.ToLower() == wasteBagType.ToLower());
        }

        public async Task<WasteBag> GetBagByItemNameAsync(string wasteItemName)
        {
            return await _context.WasteBags.Include(b => b.WasteItems).FirstOrDefaultAsync(b => b.WasteItems.Any(i => i.Name.ToLower() == wasteItemName.ToLower()));
        }

        public async Task IncreaseWasteItemCountByItemNameAsync(string wasteItemName)
        {
            var wasteItem = await _context.WasteItems
                .FirstOrDefaultAsync(i => i.Name == wasteItemName);

            // If the item exists, increment its count
            if (wasteItem != null)
            {
                wasteItem.Count += 1;

                // Save the updated count to the database
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new InvalidOperationException($"Waste item '{wasteItemName}' not found.");
            }
        }

        public async Task EmptyWasteBagByIdAsync(int bagId)
        {
            var itemsToReset = await _context.WasteItems
                .Where(i => i.WasteBagId == bagId)
                .ToListAsync();

            foreach (var item in itemsToReset)
            {
                item.Count = 0;
            }

            await _context.SaveChangesAsync();
        }
    }
}
