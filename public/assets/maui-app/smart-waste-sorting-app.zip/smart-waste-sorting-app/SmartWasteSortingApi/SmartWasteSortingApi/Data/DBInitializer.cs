﻿using SmartWasteSortingApi.Models;

namespace SmartWasteSortingApi.Data
{
    public class DBInitializer
    {
        public static void Initialize(WasteDbContext context)
        {
            context.Database.EnsureCreated();

            // Look for any WasteBags.
            if (context.WasteBags.Any())
            {
                return; // DB has been seeded
            }

            // Seed WasteBags with WasteItems
            var pmdBag = new WasteBag
            {
                BagType = "PMD",
                WasteItems = new List<WasteItem>
                {
                    new WasteItem { Name = "Plastic Fles", Count = 0 },
                    new WasteItem { Name = "Metalen Blik", Count = 0 },
                    new WasteItem { Name = "Drankkarton", Count = 0 },
                    new WasteItem { Name = "Chipszak", Count = 0 },
                }
            };

            var glassBol = new WasteBag
            {
                BagType = "GlasContainer",
                WasteItems = new List<WasteItem>
                {
                    new WasteItem { Name = "Witglas", Count = 0 },
                }
            };

            var restBag = new WasteBag
            {
                BagType = "Restafval",
                WasteItems = new List<WasteItem>
                {
                    new WasteItem { Name = "Rest", Count = 0 },
                }
            };

            context.WasteBags.AddRange(
                pmdBag,
                glassBol,
                restBag,
                new WasteBag { BagType = "Papier & Karton" },
                new WasteBag { BagType = "GFT" },
                new WasteBag { BagType = "Textiel" });

            context.SaveChanges();

        }
    }
}
