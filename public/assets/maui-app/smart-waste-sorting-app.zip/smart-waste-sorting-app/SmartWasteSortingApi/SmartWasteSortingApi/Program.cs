using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;
using SmartWasteSortingApi.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<WasteDbContext>(options =>
    options.UseSqlServer(connectionString));

builder.Services.AddScoped<IWasteRepository, WasteRepository>();

builder.Services.AddControllers().AddJsonOptions(options =>
{
    // Prevent cycles because the many to one relation model reference each other
    options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
    options.JsonSerializerOptions.WriteIndented = true;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

// Seed database
using (var scope = app.Services.CreateScope())
{
    var wasteContext = scope.ServiceProvider.GetRequiredService<WasteDbContext>();
    DBInitializer.Initialize(wasteContext);
}

app.Run();
